from copy import deepcopy
import itertools
import numpy as np
import torch
from torch.optim import Adam
import core
from replaybuffer import ReplayBuffer

import torch
import numpy as np

import tem
from normalization import Normalization, RewardScaling, action_data_normal
import matplotlib.pyplot as plt
from IPython.display import clear_output

use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")
print("using {} device.".format(device))

def plot(str,loss):
    clear_output(True)
    plt.figure(figsize=(20,5))
    plt.subplot(131)
    plt.title(str)
    plt.plot(loss)
    plt.show()


def convert_s(s):
    s = [s[0][0], s[0][1], s[0][2], s[1][0], s[1][1], s[1][2]]
    return s


def sac(env_fn, actor_critic=core.MLPActorCritic, ac_kwargs=dict(), seed=0, 
        steps_per_epoch=4000, epochs=100, replay_size=int(1e6), gamma=0.99, 
        polyak=0.995, lr=1e-3, alpha=0.2, batch_size=512, start_steps=10000,
        update_after=200, update_every=50, num_test_episodes=10, max_ep_len=200,
        logger_kwargs=dict(), save_freq=1):

    torch.manual_seed(seed)
    np.random.seed(seed)

    env, test_env = env_fn(), env_fn()

    # Action limit for clamping: critically, assumes all dimensions share the same bound!
    args.state_dim = 6
    args.action_dim = 3
    args.max_action = 100
    args.max_episode_steps = 800  # 每个episode的最大步数

    # Create actor-critic module and target networks
    ac = actor_critic(args, **ac_kwargs)
    # ac.load(20000)
    ac_targ = deepcopy(ac)

    # Freeze target networks with respect to optimizers (only update via polyak averaging)
    for p in ac_targ.parameters():
        p.requires_grad = False
        
    # List of parameters for both Q-networks (save this for convenience)
    q_params = itertools.chain(ac.q1.parameters(), ac.q2.parameters())

    # Experience buffer
    replay_buffer = ReplayBuffer(obs_dim=6, act_dim=3, size=replay_size)

    # Count variables (protip: try to get a feel for how different size networks behave!)
    var_counts = tuple(core.count_vars(module) for module in [ac.pi, ac.q1, ac.q2])


    # Set up function for computing SAC Q-losses
    def compute_loss_q(data):
        o, a, r, o2, d = data['obs'], data['act'], data['rew'], data['obs2'], data['done']

        q1 = ac.q1(o,a)
        q2 = ac.q2(o,a)

        # Bellman backup for Q functions
        with torch.no_grad():
            # Target actions come from *current* policy
            a2, logp_a2 = ac.pi(o2)

            # Target Q-values
            q1_pi_targ = ac_targ.q1(o2, a2)
            q2_pi_targ = ac_targ.q2(o2, a2)
            q_pi_targ = torch.min(q1_pi_targ, q2_pi_targ)
            backup = r + gamma * (1 - d) * (q_pi_targ - alpha * logp_a2)

        # MSE loss against Bellman backup
        loss_q1 = ((q1 - backup)**2).mean()
        loss_q2 = ((q2 - backup)**2).mean()
        loss_q = loss_q1 + loss_q2

        # Useful info for logging
        q_info = dict(Q1Vals=q1.detach().cpu().numpy(),
                      Q2Vals=q2.detach().cpu().numpy())

        return loss_q, q_info

    # Set up function for computing SAC pi loss
    def compute_loss_pi(data):
        o = data['obs']
        pi, logp_pi = ac.pi(o)
        q1_pi = ac.q1(o, pi)
        q2_pi = ac.q2(o, pi)
        q_pi = torch.min(q1_pi, q2_pi)

        # Entropy-regularized policy loss
        loss_pi = (alpha * logp_pi - q_pi).mean()

        # Useful info for logging
        pi_info = dict(LogPi=logp_pi.detach().cpu().numpy())

        return loss_pi, pi_info



    actor_loss = []
    critic_loss = []
    def update(data):
        str1 = "模型参数更新！"
        print("\033[1;32;40m", str1, "\033[0m")
        # First run one gradient descent step for Q1 and Q2
        ac.q_optimizer.zero_grad()
        loss_q, q_info = compute_loss_q(data)
        loss_q.backward()
        ac.q_optimizer.step()

        # Freeze Q-networks so you don't waste computational effort 
        # computing gradients for them during the policy learning step.
        for p in ac.q_params:
            p.requires_grad = False

        # Next run one gradient descent step for pi.
        ac.pi_optimizer.zero_grad()
        loss_pi, pi_info = compute_loss_pi(data)
        loss_pi.backward()
        ac.pi_optimizer.step()

        # Unfreeze Q-networks so you can optimize it at next DDPG step.
        for p in ac.q_params:
            p.requires_grad = True

        actor_loss.append(loss_pi)
        critic_loss.append(loss_q)

        # Finally, update target networks by polyak averaging.
        with torch.no_grad():
            for p, p_targ in zip(ac.parameters(), ac_targ.parameters()):
                # NB: We use an in-place operations "mul_", "add_" to update target
                # params, as opposed to "mul" and "add", which would make new tensors.
                p_targ.data.mul_(polyak)
                p_targ.data.add_((1 - polyak) * p.data)

    def get_action(o, deterministic=False):
        return ac.act(torch.as_tensor(o, dtype=torch.float32).to(device),
                      deterministic)

    def test_agent():
        print("testing: ")
        o, d, ep_ret, ep_len = test_env.reset(), False, 0, 0
        o = convert_s(o)
        if args.use_state_norm:
            o = state_norm(o)

        while not(d or (ep_len == args.max_episode_steps)):
            # Take deterministic actions at test time
            o, r, d, _ = test_env.step(get_action(o, True))
            o = convert_s(o)
            if args.use_state_norm:
                o = state_norm(o)
            if args.use_reward_norm:
                r = reward_norm(r)
            elif args.use_reward_scaling:
                r = reward_scaling(r)
            ep_ret += r
            ep_len += 1

    train=True

    if train:
        env = tem.satellite()
        env_evaluate = tem.satellite()
        # Set random seed
        env.seed()
        env.action_space = [-100, 100]
        env_evaluate
        env_evaluate.action_space = [-100, 100]
        np.random.seed()
        torch.manual_seed(seed)
        print("action_space为{}".format(env.action_space))

        evaluate_num = 0  # 记录评估次数
        evaluate_rewards = []  # 在评估过程中记录奖励
        total_steps = 0  # 记录训练期间的总步数
        bset_reward = -1000000000000  # 记录当前最佳奖励
        state_norm = Normalization(shape=args.state_dim)  # Trick 2:state normalization
        if args.use_reward_norm:  # Trick 3:reward normalization
            reward_norm = Normalization(shape=1)
        elif args.use_reward_scaling:  # Trick 4:reward scaling
            reward_scaling = RewardScaling(shape=1, gamma=args.gamma)

        # Main loop: collect experience in env and update/log each epoch
        while total_steps < 30000:
            o = env.reset()
            print("卫星初始位置：", o)
            o = convert_s(o)
            if args.use_state_norm:
                o = state_norm(o)
            if args.use_reward_scaling:
                reward_scaling.reset()
            episode_steps = 0
            episode_reward = 0
            total_steps += 1
            print("当前total_steps的值为：{}".format(total_steps))
            while episode_steps < args.max_episode_steps:
                episode_steps += 1
                print("当前total_steps的值为：{}".format(total_steps))
                # Until start_steps have elapsed, randomly sample actions
                # from a uniform distribution for better exploration. Afterwards,
                # use the learned policy.
                a = get_action(o)
                # Step the env
                o2, r, d, info, tag = env.step(a)
                print("采取的动作为：", a)
                print("获得的奖励为：", r)

                episode_reward += r

                # Super critical, easy to overlook step: make sure to update
                # most recent observation!
                o2 = convert_s(o2)
                if args.use_state_norm:
                    o2 = state_norm(o2)
                if args.use_reward_norm:
                    r = reward_norm(r)
                elif args.use_reward_scaling:
                    r = reward_scaling(r)

                # Store experience to replay buffer
                replay_buffer.store(o, a, r, o2, d)

                o = o2

                # Update handling
                if total_steps >= update_after and episode_steps % update_every == 0:
                    for j in range(update_every):
                        batch = replay_buffer.sample_batch(batch_size)
                        update(data=batch)

                if (total_steps + 1) % 500 == 0:
                    ac.save(total_steps + 1)

                # End of trajectory handling
                if d:
                    print("当episode_steps的值为：{}时：".format(episode_steps) + "本次episode结束")
                    break


        # Test the performance of the deterministic version of the agent.
        plot("actor_loss",actor_loss)
        plot("critic_loss",critic_loss)
        print("testing: ")
        test_agent()

    else:
        state_norm = Normalization(shape=args.state_dim)  # Trick 2:state normalization
        if args.use_reward_norm:  # Trick 3:reward normalization
            reward_norm = Normalization(shape=1)
        elif args.use_reward_scaling:  # Trick 4:reward scaling
            reward_scaling = RewardScaling(shape=1, gamma=args.gamma)
        ac.load(600000)
        test_agent()


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser("Hyperparameters Setting for PPO-continuous")
    parser.add_argument("--max_train_steps", type=int, default=int(3e6), help=" Maximum number of training steps")
    parser.add_argument("--evaluate_freq", type=float, default=5e3,
                        help="Evaluate the policy every 'evaluate_freq' steps")
    parser.add_argument("--save_freq", type=int, default=20, help="Save frequency")
    parser.add_argument("--policy_dist", type=str, default="Gaussian", help="Beta or Gaussian")
    parser.add_argument("--batch_size", type=int, default=512, help="Batch size")
    parser.add_argument("--mini_batch_size", type=int, default=64, help="Minibatch size")
    parser.add_argument('--hid', type=int, default=256)
    parser.add_argument('--l', type=int, default=2)
    parser.add_argument('--seed', '-s', type=int, default=0)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument("--lr_a", type=float, default=1e-3, help="Learning rate of actor")
    parser.add_argument("--lr_c", type=float, default=1e-3, help="Learning rate of critic")
    parser.add_argument("--gamma", type=float, default=0.99, help="Discount factor")
    parser.add_argument("--lamda", type=float, default=0.95, help="GAE parameter")
    parser.add_argument("--epsilon", type=float, default=0.2, help="PPO clip parameter")
    parser.add_argument("--K_epochs", type=int, default=10, help="PPO parameter")
    parser.add_argument("--use_adv_norm", type=bool, default=True, help="Trick 1:advantage normalization")
    parser.add_argument("--use_state_norm", type=bool, default=True, help="Trick 2:state normalization")
    parser.add_argument("--use_reward_norm", type=bool, default=False, help="Trick 3:reward normalization")
    parser.add_argument("--use_reward_scaling", type=bool, default=True, help="Trick 4:reward scaling")
    parser.add_argument("--entropy_coef", type=float, default=0.01, help="Trick 5: policy entropy")
    parser.add_argument("--use_lr_decay", type=bool, default=True, help="Trick 6:learning rate Decay")
    parser.add_argument("--use_grad_clip", type=bool, default=True, help="Trick 7: Gradient clip")
    parser.add_argument("--use_orthogonal_init", type=bool, default=True, help="Trick 8: orthogonal initialization")
    parser.add_argument("--set_adam_eps", type=float, default=True, help="Trick 9: set Adam epsilon=1e-5")
    parser.add_argument("--use_tanh", type=float, default=True, help="Trick 10: tanh activation function")
    parser.add_argument("--actor_best_save_path", type=str, default="./runs/exp/best_model/actor.pth",
                        help="actor模型保存地址")
    parser.add_argument("--critic_best_save_path", type=str, default="./runs/exp/best_model/critic.pth",
                        help="critic模型保存地址")
    parser.add_argument("--actor_latest_save_path", type=str, default="./runs/exp/latest_model/actor.pth",
                        help="actor模型保存地址")
    parser.add_argument("--critic_latest_save_path", type=str, default="./runs/exp/latest_model/critic.pth",
                        help="critic模型保存地址")
    args = parser.parse_args()



    torch.set_num_threads(torch.get_num_threads())

    sac(lambda : tem.satellite(), actor_critic=core.MLPActorCritic,
        ac_kwargs=dict(hidden_sizes=[args.hid]*args.l), 
        gamma=args.gamma, seed=args.seed, epochs=args.epochs,
        )
